const grid = document.getElementById('grid');
const images = [
    'memorama1.jpg',
    'memorama2.jpg',
    'memorama3.jpg',
    'memorama4.jpg',
    'memorama5.jpg',
    'memorama6.jpg',
    'memorama7.jpg',
    'memorama8.jpg',
    'memorama9.jpg',
    'memorama10.jpg',
];

let flippedCards = [];
let matchedCards = [];

function tarjetas() {
    const shuffledImages = [...images, ...images].sort(() => 0.5 - Math.random());

    for (let i = 0; i < shuffledImages.length; i++) {
        const card = document.createElement('div');
        card.classList.add('card');
        const image = document.createElement('img');
        image.src = shuffledImages[i];
        card.appendChild(image);

        card.addEventListener('click', () => vuelta(card));

        grid.appendChild(card);
    }
}
function vuelta(card) {
    if (flippedCards.length < 2 && !flippedCards.includes(card)) {
        card.classList.add('flipped');
        card.firstChild.style.display = 'block';
        flippedCards.push(card);

        if (flippedCards.length === 2) {
            setTimeout(verifinacion, 1000);
        }
    }
}


function verifinacion() {
    const [card1, card2] = flippedCards;
    const image1 = card1.firstChild.src;
    const image2 = card2.firstChild.src;

    if (image1 === image2) {
        matchedCards.push(card1, card2);
        flippedCards = [];

        if (matchedCards.length === images.length * 2) {
            alert('¡Ganaste!');
            reiniciar();
        }
    } else {
        setTimeout(() => {
            card1.classList.remove('flipped');
            card2.classList.remove('flipped');
            card1.firstChild.style.display = 'none';
            card2.firstChild.style.display = 'none';
            flippedCards = [];
        }, 1000);
    }
}


function reiniciar() {
    grid.innerHTML = '';
    matchedCards = [];
    flippedCards = [];
    tarjetas();
}

tarjetas();
